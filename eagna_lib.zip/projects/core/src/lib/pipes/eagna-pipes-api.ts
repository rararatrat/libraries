export * from './eagna-pipes.module';
export * from './eagna.pipe';
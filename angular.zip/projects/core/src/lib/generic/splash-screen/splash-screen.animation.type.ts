export enum SplashAnimationType {
    SlideLeft = "slide-left",
    SlideRight = "slide-right",
    FadeOut = "fade-out"
  }